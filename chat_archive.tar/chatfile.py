#!/usr/bin/python3
import sys
import subprocess
import string

work = []

inputfile = sys.argv[1]
outputfile = str(sys.argv[2])

with open(str(inputfile), 'r') as fi:
	for line in fi:
		work.append(line.strip())


new = []
for line in work:
	s = line
	translator = line.maketrans('', '', string.punctuation)
	line = line.translate(translator)
	line = "How do i " + line + " for ccna"
	new.append(line)
print(new)

ultimate = []
for line in work:
	feed = subprocess.run(["bash", "call", line], capture_output=True)
	x = feed.stdout.decode().strip('""').replace("\\n", "").strip('""').strip("''")
	ultimate.append(x)
	print(x)
	
print(ultimate)
with open(outputfile, "w") as F:
	F.writelines("%s\n" % item for item in ultimate)

